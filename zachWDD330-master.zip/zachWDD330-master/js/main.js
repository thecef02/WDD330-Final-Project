const links = [
    {
      label: "Home",
      url: "index.html"
    },
    {
      label: "Final",
      url: "project/index.html"
    },
    {
        label: "Week1 notes",
        url: "week1/index.html"
    },
    {
        label: "Week2 notes",
        url: "week2/index.html"
    },
    {
      label: "Week3 notes",
      url: "week3/index.html"
    },
    {
      label: "Week4 notes",
      url: "week4/index.html"
    },
    {
      label: "Week5 notes",
      url: "week5/index.html"
    },
    {
      label: "Week6 Todo",
      url: "week6/index.html"
    },
    {
      label: "Week7 notes",
      url: "week7/index.html"
    },
    {
      label: "Week8 notes",
      url: "week8/index.html"
    },
    {
      label: "Week9 notes",
      url: "week9/index.html"
    },
    {
      label: "Week10 notes",
      url: "week10/index.html"
    }
    
];

function makeList(){

for (let i = 0; i < links.length; i++ ) 
  {
    let entry = document.createElement('li');
    let link = document.createElement('a');
    
    link.textContent = '' + links[i].label;
    link.setAttribute('href', links[i].url)
    
    entry.appendChild(link);

    document.querySelector('ol#dynamicLinkList').appendChild(entry);
  }
  
  
}

