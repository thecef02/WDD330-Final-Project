

//Signup

var popup = document.getElementById('signup');

window.onclick = function(event) {
  if (event.target == popup) {
    popup.style.display = "none";
  }
}

